package com.compoundtheory.asyncHTTP;

import java.net.URL;

import HTTPClient.HTTPConnection;

/**
 * Abstract HTTPThread class for running a
 * HTTP request via a thread model
 * 
 * @author Mark Mandel
 *
 */

public abstract class HTTPThread extends Thread
{
	private HTTPConnection connection;
	private URL url;
	
	protected HTTPThread(HTTPConnection conn, URL url)
	{
		setConnection(conn);
		setURL(url);
	}
	
	protected URL getURL()
	{
		return url;
	}

	private void setURL(URL url)
	{
		this.url = url;
	}

	protected HTTPConnection getConnection()
	{
		return connection;
	}

	private void setConnection(HTTPConnection connection)
	{
		this.connection = connection;
	}	
}
