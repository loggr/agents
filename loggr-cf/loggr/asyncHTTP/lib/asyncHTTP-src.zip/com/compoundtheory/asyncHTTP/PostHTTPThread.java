/**
 * 
 */
package com.compoundtheory.asyncHTTP;

import java.net.URL;
import java.util.*;
import HTTPClient.*;

import HTTPClient.HTTPConnection;

/**
 * Asynchronous POST request
 * @author Mark Mandel
 *
 */
public class PostHTTPThread extends HTTPThread
{
	
	//variables
	private NVPair[] formValues;
	
	/**
	 * New POST request
	 * @param conn The HTTPConnection to make the request with
	 * @param url The URL To post to
	 */
	public PostHTTPThread(HTTPConnection conn, URL url,  Hashtable formData)
	{
		super(conn, url);
		
		//convert form data
		NVPair[] formValues = new NVPair[formData.size()];
		
		Iterator iterator = formData.keySet().iterator();
		int counter = 0;
		
		while(iterator.hasNext())
		{
			String key = (String)iterator.next();
			NVPair formElement = new NVPair(key, (String)formData.get(key));
			formValues[counter++] = formElement;
		}
		
		setFormValues(formValues);
	}
	
	public void run()
	{
		try
		{
			getConnection().Post(getURL().getFile(), getFormValues());
		}
		catch(Throwable exc)
		{
			System.out.println("Error on POST thread: " + exc.getMessage());
			exc.printStackTrace();				
		}
	}	

	private NVPair[] getFormValues()
	{
		return formValues;
	}

	private void setFormValues(NVPair[] formValues)
	{
		this.formValues = formValues;
	}
}
