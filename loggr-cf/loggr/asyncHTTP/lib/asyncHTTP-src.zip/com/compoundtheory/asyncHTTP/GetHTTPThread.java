package com.compoundtheory.asyncHTTP;

import java.net.*;
import HTTPClient.*;

/**
 * Asynchronous GET request
 * @author Mark Mandel
 *
 */

public class GetHTTPThread extends HTTPThread
{
	public GetHTTPThread(HTTPConnection conn, URL url)
	{
		super(conn, url);
	}
	
	public void run()
	{
		try
		{
			getConnection().Get(getURL().getFile());
		}
		catch(Throwable exc)
		{
			System.out.println("Error on get thread: " + exc.getMessage());
			exc.printStackTrace();				
		}
	}
}
