package com.compoundtheory.asyncHTTP;

import java.net.*;
import java.util.*;
import HTTPClient.*;

/**
 * Asynchronous HTTP calls, using the
 * HTTPClient classes
 * 
 * @author Mark Mandel
 *
 */
public class AsyncHTTP
{
	public AsyncHTTP()
	{
		
	}
	
	public void post()
	{
		
	}
	/**
	 * Does an async GET to the given URL
	 * @param url The URL to GET from.
	 */
	public void get(URL url)
	{
		try
		{
			HTTPConnection conn = new HTTPConnection(url);
			GetHTTPThread http = new GetHTTPThread(conn, url);
			
			http.start();
		}
		catch(ProtocolNotSuppException exc)
		{
			System.out.println("Error on GET: " + exc.getMessage());
			exc.printStackTrace();
		}
	}
	
	public void post(URL url, Hashtable formData)
	{
		try
		{
			HTTPConnection conn = new HTTPConnection(url);
			PostHTTPThread http = new PostHTTPThread(conn, url, formData);
			
			http.start();
		}
		catch(ProtocolNotSuppException exc)
		{
			System.out.println("Error on POST: " + exc.getMessage());
			exc.printStackTrace();
		}		
	}
}
